import { Router } from 'express';
import { db } from '../db';
import { servicos } from '../db/schema';
import { eq } from 'drizzle-orm';

const router = Router();

// GET /servicos - listar todos
router.get('/', async (req, res) => {
  const lista = db.select().from(servicos).all();
  res.json(lista);
});

// GET /servicos/:id - buscar por id
router.get('/:id', async (req, res) => {
  const item = db.select().from(servicos)
    .where(eq(servicos.id, Number(req.params.id)))
    .get();

  if (!item) return res.status(404).json({ erro: 'Serviço não encontrado' });
  res.json(item);
});

// POST /servicos - criar
router.post('/', async (req, res) => {
  const { descricao, valor } = req.body;

  if (!descricao || valor === undefined)
    return res.status(400).json({ erro: 'descricao e valor são obrigatórios' });

  const novo = db.insert(servicos).values({ descricao, valor }).returning().get();
  res.status(201).json(novo);
});

// PUT /servicos/:id - atualizar
router.put('/:id', async (req, res) => {
  const { descricao, valor } = req.body;
  const id = Number(req.params.id);

  const existe = db.select().from(servicos).where(eq(servicos.id, id)).get();
  if (!existe) return res.status(404).json({ erro: 'Serviço não encontrado' });

  const atualizado = db.update(servicos)
    .set({ descricao, valor })
    .where(eq(servicos.id, id))
    .returning()
    .get();

  res.json(atualizado);
});

// DELETE /servicos/:id - deletar
router.delete('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const existe = db.select().from(servicos).where(eq(servicos.id, id)).get();
  if (!existe) return res.status(404).json({ erro: 'Serviço não encontrado' });

  db.delete(servicos).where(eq(servicos.id, id)).run();
  res.status(204).send();
});

export default router;
