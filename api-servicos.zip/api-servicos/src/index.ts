import express from 'express';
import servicosRouter from './routes/servicos';

const app = express();
app.use(express.json());

app.use('/servicos', servicosRouter);

app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});
