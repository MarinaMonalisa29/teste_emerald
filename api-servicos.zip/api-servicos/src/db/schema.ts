import { sqliteTable, integer, text, real } from 'drizzle-orm/sqlite-core';

export const servicos = sqliteTable('servicos', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  descricao: text('descricao').notNull(),
  valor: real('valor').notNull(),
});
